package cmsc433;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * Cooks are simulation actors that have at least one field, a name.
 * When running, a cook attempts to retrieve outstanding orders placed
 * by Customer and process them.
 */
public class Cook implements Runnable {
	private final String name;
	private HashMap<Food, Machines> machinesByFood;
	private HashMap<Integer, HashMap<Food, LinkedList<Thread>>> foodThreadsByOrderNumber;

	/**
	 * You can feel free modify this constructor. It must
	 * take at least the name, but may take other parameters
	 * if you would find adding them useful.
	 *
	 * @param: the name of the cook
	 */
	public Cook(String name, HashMap<Food, Machines> machinesByFood) {
		this.name = name;
		this.machinesByFood = machinesByFood;
		this.foodThreadsByOrderNumber = new HashMap<Integer, HashMap<Food, LinkedList<Thread>>>();
	}

	public String toString() {
		return name;
	}

	/**
	 * This method executes as follows. The cook tries to retrieve
	 * orders placed by Customers. For each order, a List<Food>, the
	 * cook submits each Food item in the List to an appropriate
	 * Machine type, by calling makeFood(). Once all machines have
	 * produced the desired Food, the order is complete, and the Customer
	 * is notified. The cook can then go to process the next order.
	 * If during its execution the cook is interrupted (i.e., some
	 * other thread calls the interrupt() method on it, which could
	 * raise InterruptedException if the cook is blocking), then it
	 * terminates.
	 */
	public void run() {

		Simulation.logEvent(SimulationEvent.cookStarting(this));
		try {
			while (true) {
				// YOUR CODE GOES HERE..
				
				Integer orderNum;
				synchronized(Simulation.getNewOrders()) {
					while(!Simulation.hasNewOrders()) {
						Simulation.getNewOrders().wait();
					}
					HashSet<Integer> newOrders = Simulation.getNewOrders();
					synchronized(newOrders) {
						while (newOrders.size()==0) {
							try {
								if (Simulation.allOrdersFinished()==true) {
									orderNum = -1;
								}
								newOrders.wait();
							} catch (InterruptedException e) {
								System.out.println(e);
							}
						}
						ArrayList<Integer> orderNums = new ArrayList<Integer>(newOrders);
						if(!orderNums.isEmpty()) {
							orderNum = orderNums.get(orderNums.size()-1);
							newOrders.remove(orderNum);
						} else {
							orderNum = -1;
						}
					}
				}
				
				
				
				List<Food> order = Simulation.getOrder(orderNum);
				
				synchronized (Simulation.getOrderLock(orderNum)) {
					Simulation.logEvent(SimulationEvent.cookReceivedOrder(this, order, orderNum));
					foodThreadsByOrderNumber.put(orderNum, new HashMap<Food, LinkedList<Thread>>());

					HashMap<Food, Integer> foodTypeCount = new HashMap<Food, Integer>();
					for (Food food : order) {
						foodTypeCount.put(food, foodTypeCount.containsKey(food)?foodTypeCount.get(food)+1:0);
					}
					
					for(Food food: foodTypeCount.keySet()) {
						foodThreadsByOrderNumber.get(orderNum).put(food, new LinkedList<Thread>());
						for (int j = 0; j < foodTypeCount.get(food); j++) {
							Simulation.logEvent(SimulationEvent.cookStartedFood(this, food, orderNum));
							Simulation.startOrder(this, orderNum);
							foodThreadsByOrderNumber.get(orderNum).get(food).add(machinesByFood.get(food).makeFood(food));
						}
					}
					
					for (Food food : foodThreadsByOrderNumber.get(orderNum).keySet()) {
						for (Thread thread : foodThreadsByOrderNumber.get(orderNum).get(food)) {
							thread.join();
							Simulation.logEvent(SimulationEvent.cookFinishedFood(this, food, orderNum));
						}
					}
					
					Simulation.completeOrder(this, orderNum);
					Simulation.logEvent(SimulationEvent.cookCompletedOrder(this, orderNum));
				}
			}
		} catch (InterruptedException e) {
			// This code assumes the provided code in the Simulation class
			// that interrupts each cook thread when all customers are done.
			// You might need to change this if you change how things are
			// done in the Simulation class.
			Simulation.logEvent(SimulationEvent.cookEnding(this));
		}
	}
	
	
	
	
	
}
